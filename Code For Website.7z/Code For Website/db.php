<?php
$con=mysqli_connect("localhost","id16513288_admin","wR/oi2p[ghL8/U%H","id16513288_gases");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 
?>
